

$(document).ready(function () {
    function fetchSuggestions(inputText) {
        var words = inputText.split(/\s+/);
        var lastWord = words[words.length - 1];
        if (lastWord.length > 0) {
            $.get(`/suggestions?prefix=${lastWord}`, function (data) {
                var suggestions = data.slice(0, 100); // Limit suggestions to 20 words
                var html = "";
                for (var i = 0; i < suggestions.length; i++) {
                    if (suggestions[i].startsWith(lastWord)) {
                        html += `<div class="words">${suggestions[i]}</div>`;
                    }
                }
                $('#suggestions').html(html);
            });
        } else {
            $('#suggestions').html(''); 
        }
    }
    $('#searchInput').on('input', function () {
        var inputText = $(this).val().trim();
        fetchSuggestions(inputText); 
    });
    $('#suggestions').on('mouseenter', '.words', function () {
        $('.words').removeClass('selected');
        $(this).addClass('selected');
    });

    $('#suggestions').on('mouseleave', '.words', function () {
        $('.words').removeClass('selected');
    });

    $('#suggestions').on('click', '.words', function () {
        var selectedWord = $(this).text();
        var inputText = $('#searchInput').val().trim();
        var words = inputText.split(/\s+/);
        words[words.length - 1] = selectedWord;
        $('#searchInput').val(words.join(" "));
        $('#suggestions').html(''); 
    });
});

