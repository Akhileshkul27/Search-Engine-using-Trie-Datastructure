# Auto-Complete-Trie-DS(Dictionary Words)
-

  
  -> Intially I have add a txt file consisting of 37k english words in trie .

  -> when you start typing something then it shows all the words that matches to it .
  
  Check Here  : https://frosty-aryabhata-f91016.netlify.app
  
  Demo
  -
  
![search-engine](https://user-images.githubusercontent.com/54505967/84342575-849bd900-abc3-11ea-9947-561abd797d95.gif)
  
